from setuptools import find_packages, setup

package_name = 'ps6_py_control_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='nobel',
    maintainer_email='134955841+NOOBOTICS@users.noreply.github.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            '1st_node = ps6_py_control_pkg.1st_node:main',
            'right_wall_control_old = ps6_py_control_pkg.right_wall_control_old:main',
            'ps6_camnode = ps6_py_control_pkg.ps6_camnode:main',
            'odom = ps6_py_control_pkg.odom:main',
            'kmeans_client_and_cluster = ps6_py_control_pkg.kmeans_client_and_cluster:main',
            'k_means = ps6_py_control_pkg.k_means:main'
        ],
    },
)
