import rclpy
import math
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion
from arm_interface_pkg.msg import CoordLabel, CoordLabelArray
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan


class OdomSubscriber(Node):
    def __init__(self):
        super().__init__('odom_subscriber')
        self.odom_subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10
        )

        self.cam_subscription = self.create_subscription(
            CoordLabelArray,
            '/cam_topic',
            self.cam_callback,
            10
        )

        self.scan_subscription = self.create_subscription(
            LaserScan, 
            'scan', 
            self.scan_callback, 
            10
        )
        
        self.ranges = [0]*360


        self.pub = self.create_publisher(CoordLabelArray, "obj/coord/label", 10)



    def cam_callback(self, msg: CoordLabelArray):
        coordlabelarr = msg.entries  # Access the list of CoordLabel objects
        theta = self.yaw
        x1 = self.x
        y1 = self.y
        self.objarr = []
        self.pubarr = CoordLabelArray()

        for coord_label in coordlabelarr:
            angle = coord_label.x
            label = coord_label.label
            alp = theta - angle

            angle_index = int(angle)
            if angle_index >= 0:
                d = self.ranges[angle_index]
            else:
                d = self.ranges[360 + angle_index]

            obj_x = d * math.cos(math.radians(alp)) + x1
            obj_y = d * math.sin(math.radians(alp)) + y1
            self.objarr.append([obj_x, obj_y, label])

            # Create a new CoordLabel instance for publishing
            pub_entry = CoordLabel()
            pub_entry.x = obj_x
            pub_entry.y = obj_y
            pub_entry.label = label
            self.pubarr.entries.append(pub_entry)  # Append to the list in CoordLabelArray

        self.pub.publish(self.pubarr)



        


    def scan_callback(self, msg = LaserScan):
        self.ranges = msg.ranges
        # self.range[0] belongs to front laser distance 
        # self.ranges[180] then will be behind
        # self.ranges[270] is right laser data 
        # self.ranes[90] is left laser data


    def odom_callback(self, msg = Odometry):
        # Extract position
        self.x = msg.pose.pose.position.x     # x, y z current 
        self.y = msg.pose.pose.position.y
        self.z = msg.pose.pose.position.z

        # Extract orientation in quaternion
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        
        # Convert quaternion to Euler angles
        roll, pitch, self.yaww = euler_from_quaternion(orientation_list)    ### bot angle 
        self.yaw = math.degrees(self.yaww)     ### bot angle 



def main(args=None):
    rclpy.init(args=args)
    odom_subscriber = OdomSubscriber()
    rclpy.spin(odom_subscriber)

    odom_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
