import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import ComputePathToPose
from geometry_msgs.msg import PoseStamped
from math import sqrt


class PathLengthActionClient(Node):
    def __init__(self):
        super().__init__('path_length_action_client')

        # Create an Action Client for ComputePathToPose
        self.action_client = ActionClient(self, ComputePathToPose, '/compute_path_to_pose')

        # Define the goal pose
        self.goal_pose = PoseStamped()
        self.goal_pose.header.frame_id = 'map'
        self.goal_pose.pose.position.x = 4.0
        self.goal_pose.pose.position.y = 0.0
        self.goal_pose.pose.position.z = 0.0
        self.goal_pose.pose.orientation.x = 0.0
        self.goal_pose.pose.orientation.y = 0.0
        self.goal_pose.pose.orientation.z = 0.0
        self.goal_pose.pose.orientation.w = 1.0

        # Send the goal
        self.send_goal()

    def send_goal(self):
        # Define the goal request
        goal_msg = ComputePathToPose.Goal()
        goal_msg.goal = self.goal_pose
        goal_msg.planner_id = ''
        goal_msg.use_start = False

        self.get_logger().info('Waiting for action server...')
        self.action_client.wait_for_server()

        self.get_logger().info('Sending goal...')
        self._send_goal_future = self.action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Goal was rejected by the server.')
            return

        self.get_logger().info('Goal accepted by the server.')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Result received.')

        # Check if the path is valid and calculate its length
        if result.path.poses:  # Ensure the path has poses
            path_length = self.calculate_path_length(result.path)
            self.get_logger().info(f'Path length: {path_length:.2f} meters')
        else:
            self.get_logger().error('Received an empty path from the server.')

        

    def feedback_callback(self, feedback_msg):
        self.get_logger().info('Received feedback.')

    @staticmethod
    def calculate_path_length(path):
        length = 0.0
        for i in range(1, len(path.poses)):
            x1, y1 = path.poses[i - 1].pose.position.x, path.poses[i - 1].pose.position.y
            x2, y2 = path.poses[i].pose.position.x, path.poses[i].pose.position.y
            length += sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        return length


def main(args=None):
    rclpy.init(args=args)
    node = PathLengthActionClient()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
