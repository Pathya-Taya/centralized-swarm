import rclpy
from rclpy.action import ActionClient
from nav2_msgs.action import ComputePathToPose
from geometry_msgs.msg import PoseStamped
import math

def calculate_distance(p1, p2):
    return math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

def main():
    rclpy.init()
    node = rclpy.create_node('path_distance_computer')

    action_client = ActionClient(node, ComputePathToPose, '/tb3/compute_path_to_pose')

    # Wait until the action server is available
    node.get_logger().info('Waiting for action server...')
    action_client.wait_for_server()

    # Prepare the goal message
    goal_msg = ComputePathToPose.Goal()
    goal_msg.goal_pose.header.frame_id = 'map'
    goal_msg.goal_pose.header.stamp = node.get_clock().now().to_msg()
    goal_msg.goal_pose.pose.position.x = 2.0  # Target x
    goal_msg.goal_pose.pose.position.y = 3.0  # Target y
    goal_msg.goal_pose.pose.orientation.w = 1.0  # Neutral orientation

    # Send the goal
    future = action_client.send_goal_async(goal_msg)
    rclpy.spin_until_future_complete(node, future)

    goal_handle = future.result()
    if not goal_handle.accepted:
        node.get_logger().info('Goal rejected')
        return

    node.get_logger().info('Goal accepted')
    result_future = goal_handle.get_result_async()
    rclpy.spin_until_future_complete(node, result_future)

    result = result_future.result().result
    total_distance = 0.0

    # Compute the total path distance
    for i in range(1, len(result.path.poses)):
        p1 = result.path.poses[i - 1].pose.position
        p2 = result.path.poses[i].pose.position
        total_distance += calculate_distance(p1, p2)

    node.get_logger().info(f'Total path distance: {total_distance} meters')

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
