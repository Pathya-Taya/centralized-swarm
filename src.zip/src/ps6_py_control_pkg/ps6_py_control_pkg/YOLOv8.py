import numpy as np
import matplotlib.pyplot as plt
from ultralytics import YOLO

class Model:
  def __init__(self):
    self.model = YOLO('yolov8n.pt')

  def predict(self, img, about_centre=True):
    results = self.model(img)
    pts = results[0].boxes.xywh[:,:2].numpy()
    if about_centre:
      pts[:,0] -= img.shape[1]/2
      pts[:,1] -= img.shape[0]/2
    classes = np.array([self.model.names[int(j)] for j in results[0].boxes.cls.tolist()])
    pts = np.hstack((pts, classes[:,None])).astype(object)
    pts[:,0] = pts[:,0].astype('float64')
    pts[:,1] = pts[:,1].astype('float64')
    return pts
    
  def plot_predictions(self,img):
    pts = self.predict(img,False)
    plt.imshow(img)
    plt.scatter(pts[:, 0], pts[:, 1], marker="x", color="red", s=200)
