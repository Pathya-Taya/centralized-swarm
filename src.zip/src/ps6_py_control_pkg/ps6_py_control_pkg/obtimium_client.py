from arm_interface_pkg.srv import TurtleOptPath
from ps6_py_control_pkg import laber_with_cord as data
import rclpy
from rclpy.node import Node
from nav2_msgs.action import ComputePathToPose
from rclpy.action import ActionClient
from rclpy.client import Client
from tf_transformations import quaternion_from_euler
from geometry_msgs.msg import PoseStamped
from math import sqrt
from arm_interface_pkg.srv import Navigator


class MinimalService(Node):
    def __init__(self, num_robots):
        super().__init__('minimal_service')

        # Create service
        self.srv = self.create_service(TurtleOptPath, 'optimium_bot', self.optimium_bot)

        # Initialize action clients dynamically
        self.num_robots = num_robots
        self.action_clients = [
            ActionClient(self, ComputePathToPose, f'tb{i+1}/compute_path_to_pose') for i in range(self.num_robots)
        ]

        # Create client for the Navigator service
        self.navigator_client = self.create_client(Navigator, 'navigate_robot')

        # Initialize path lengths for each bot
        self.path_lengths = {f"tb{i+1}": [] for i in range(self.num_robots)}

        # Tracking the total goals and responses
        self.total_goals = 0
        self.responses_received = 0

        # Variables to track the optimal bot
        self.min_path_length = float('inf')
        self.min_bot = ''
        self.min_x = 0
        self.min_y = 0

    def create_pose(self, x, y, z, ox, oy, oz):
        oxx, oyy, ozz, oww = quaternion_from_euler(ox, oy, oz)
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        pose.pose.position.z = float(z)
        pose.pose.orientation.x = oxx
        pose.pose.orientation.y = oyy
        pose.pose.orientation.z = ozz
        pose.pose.orientation.w = oww
        return pose

    def send_goal(self, action_client, bot_label, goal_pose):
        goal_msg = ComputePathToPose.Goal()
        goal_msg.goal = goal_pose
        goal_msg.planner_id = ''
        goal_msg.use_start = False

        action_client.wait_for_server()
        self._send_goal_future = action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(lambda future: self.goal_response_callback(future, bot_label, goal_pose))

    def goal_response_callback(self, future, bot_label, goal_pose):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error(f'Goal for {bot_label} to ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) was rejected.')
            return

        self.get_logger().info(f'Goal for {bot_label} to ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) accepted.')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(lambda future: self.result_callback(future, bot_label, goal_pose))

    def result_callback(self, future, bot_label, goal_pose):
        result = future.result().result
        if result.path.poses:
            path_length = self.calculate_path_length(result.path)
            self.get_logger().info(
                f'{bot_label} | Goal: ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) | Path length: {path_length:.2f} meters'
            )

            if path_length < self.min_path_length:
                self.min_path_length = path_length
                self.min_x = goal_pose.pose.position.x
                self.min_y = goal_pose.pose.position.y
                self.min_bot = bot_label

            # Track the number of responses received
            self.responses_received += 1

            # Check if all responses have been processed
            if self.responses_received == self.total_goals:
                self.send_navigation_request()
        else:
            self.get_logger().error(
                f'{bot_label} | Received an empty path for goal ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}).'
            )

    def feedback_callback(self, feedback_msg):
        self.get_logger().info('Received feedback.')

    @staticmethod
    def calculate_path_length(path):
        length = 0.0
        for i in range(1, len(path.poses)):
            x1, y1 = path.poses[i - 1].pose.position.x, path.poses[i - 1].pose.position.y
            x2, y2 = path.poses[i].pose.position.x, path.poses[i].pose.position.y
            length += sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        return length

    def optimium_bot(self, request, response):
        requested_item = request.label
        self.min_path_length = float('inf')
        self.min_bot = ''
        self.min_x = 0
        self.min_y = 0
        self.responses_received = 0

        if requested_item in data.label:
            coordinates = data.label[requested_item]
            self.total_goals = len(coordinates) * self.num_robots

            for coord in coordinates:
                goal_pose = self.create_pose(coord[0], coord[1], 0, 0, 0, 0)
                for i, action_client in enumerate(self.action_clients):
                    bot_label = f"tb{i+1}"
                    self.send_goal(action_client, bot_label, goal_pose)
        else:
            self.get_logger().error('No such item in the environment.')
            response.bot = 'Failure'

        response.bot = self.min_bot
        response.x = float(self.min_x)
        response.y = float(self.min_y)
        return response

    def send_navigation_request(self):
        # Wait for the Navigator service to be available
        if not self.navigator_client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error("Navigator service is not available.")
            return

        # Create a request
        request = Navigator.Request()
        request.robot_namespace = self.min_bot
        request.x_goal = self.min_x
        request.y_goal = self.min_y
        request.yaw_goal = 0.0  # Set yaw to 0.0 for simplicity

        # Send the request and handle the response
        future = self.navigator_client.call_async(request)
        future.add_done_callback(self.handle_navigation_response)

    def handle_navigation_response(self, future):
        try:
            response = future.result()
            if response.success:
                self.get_logger().info(f"Navigation request succeeded for {self.min_bot} to ({self.min_x}, {self.min_y}).")
            else:
                self.get_logger().error(f"Navigation request failed for {self.min_bot}.")
        except Exception as e:
            self.get_logger().error(f"Service call failed: {e}")


def main(args=None):
    rclpy.init(args=args)
    num_robots = 4
    minimal_service = MinimalService(num_robots)
    rclpy.spin(minimal_service)
    rclpy.shutdown()


if __name__ == '__main__':
    main()




# from arm_interface_pkg.srv import TurtleOptPath
# from ps6_py_control_pkg import laber_with_cord as data
# import rclpy
# from rclpy.node import Node
# from nav2_msgs.action import ComputePathToPose
# from rclpy.action import ActionClient
# from tf_transformations import quaternion_from_euler
# from geometry_msgs.msg import PoseStamped
# from math import sqrt
# from std_msgs.msg import String
# from arm_interface_pkg.srv import Navigator

# class MinimalService(Node):
#     def __init__(self, num_robots):
#         super().__init__('minimal_service')

#         # Create service
#         self.srv = self.create_service(TurtleOptPath, 'optimium_bot', self.optimium_bot)

#         # Create publisher for optimal bot and coordinates
#         self.publisher = self.create_publisher(String, 'optimal_bot_info', 10)

#         # Initialize action clients dynamically
#         self.num_robots = num_robots
#         self.action_clients = [
#             ActionClient(self, ComputePathToPose, f'tb{i+1}/compute_path_to_pose') for i in range(self.num_robots)
#         ]

#         # Initialize path lengths for each bot
#         self.path_lengths = {f"tb{i+1}": [] for i in range(self.num_robots)}

#         # Tracking the total goals and responses
#         self.total_goals = 0
#         self.responses_received = 0

#         # Variables to track the optimal bot
#         self.min_path_length = float('inf')
#         self.min_bot = ''
#         self.min_x = 0
#         self.min_y = 0

#         # Create service client for robot navigation service
#         self.robot_goal_client = self.create_client(Navigator, 'navigate_robot')

#     def create_pose(self, x, y, z, ox, oy, oz):
#         oxx, oyy, ozz, oww = quaternion_from_euler(ox, oy, oz)
#         pose = PoseStamped()
#         pose.header.frame_id = 'map'
#         pose.pose.position.x = float(x)
#         pose.pose.position.y = float(y)
#         pose.pose.position.z = float(z)
#         pose.pose.orientation.x = oxx
#         pose.pose.orientation.y = oyy
#         pose.pose.orientation.z = ozz
#         pose.pose.orientation.w = oww
#         return pose

#     def send_goal(self, action_client, bot_label, goal_pose):
#         goal_msg = ComputePathToPose.Goal()
#         goal_msg.goal = goal_pose
#         goal_msg.planner_id = ''
#         goal_msg.use_start = False

#         action_client.wait_for_server()
#         self._send_goal_future = action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
#         self._send_goal_future.add_done_callback(lambda future: self.goal_response_callback(future, bot_label, goal_pose))

#     def goal_response_callback(self, future, bot_label, goal_pose):
#         goal_handle = future.result()
#         if not goal_handle.accepted:
#             self.get_logger().error(f'Goal for {bot_label} to ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) was rejected.')
#             return

#         self.get_logger().info(f'Goal for {bot_label} to ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) accepted.')
#         self._get_result_future = goal_handle.get_result_async()
#         self._get_result_future.add_done_callback(lambda future: self.result_callback(future, bot_label, goal_pose))

#     def result_callback(self, future, bot_label, goal_pose):
#         result = future.result().result
#         if result.path.poses:
#             path_length = self.calculate_path_length(result.path)
#             self.get_logger().info(
#                 f'{bot_label} | Goal: ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}) | Path length: {path_length:.2f} meters'
#             )

#             if path_length < self.min_path_length:
#                 self.min_path_length = path_length
#                 self.min_x = goal_pose.pose.position.x
#                 self.min_y = goal_pose.pose.position.y
#                 self.min_bot = bot_label

#             # Track the number of responses received
#             self.responses_received += 1

#             # Check if all responses have been processed
#             if self.responses_received == self.total_goals:
#                 self.publish_final_result()
#         else:
#             self.get_logger().error(
#                 f'{bot_label} | Received an empty path for goal ({goal_pose.pose.position.x}, {goal_pose.pose.position.y}).'
#             )

#     def feedback_callback(self, feedback_msg):
#         self.get_logger().info('Received feedback.')

#     @staticmethod
#     def calculate_path_length(path):
#         length = 0.0
#         for i in range(1, len(path.poses)):
#             x1, y1 = path.poses[i - 1].pose.position.x, path.poses[i - 1].pose.position.y
#             x2, y2 = path.poses[i].pose.position.x, path.poses[i].pose.position.y
#             length += sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
#         return length

#     def optimium_bot(self, request, response):
#         requested_item = request.label
#         self.min_path_length = float('inf')
#         self.min_bot = ''
#         self.min_x = 0
#         self.min_y = 0
#         self.responses_received = 0

#         if requested_item in data.label:
#             coordinates = data.label[requested_item]
#             self.total_goals = len(coordinates) * self.num_robots

#             for coord in coordinates:
#                 goal_pose = self.create_pose(coord[0], coord[1], 0, 0, 0, 0)
#                 for i, action_client in enumerate(self.action_clients):
#                     bot_label = f"tb{i+1}"
#                     self.send_goal(action_client, bot_label, goal_pose)
                    
#                     # Send request to the robot goal service for each robot and goal
#                     robot_namespace = f"tb{i+1}"
#                     x_goal, y_goal, yaw_goal = coord[0], coord[1], 0.0  # Adjust yaw as needed
#                     self.send_robot_goal_request(robot_namespace, x_goal, y_goal, yaw_goal)
#         else:
#             self.get_logger().error('No such item in the environment.')
#             response.bot = 'Failure'

#         response.bot = self.min_bot
#         response.x = float(self.min_x)
#         response.y = float(self.min_y)
#         return response

#     def send_robot_goal_request(self, robot_namespace, x_goal, y_goal, yaw_goal):
#         # Create a request message
#         request = Navigator.Request()
#         request.robot_namespace = robot_namespace
#         request.x_goal = x_goal
#         request.y_goal = y_goal
#         request.yaw_goal = yaw_goal

#         # Call the service and send coordinates for the request
#         self.get_logger().info(f"Requesting goal for {robot_namespace} with coordinates ({x_goal}, {y_goal}, {yaw_goal})")
        
#         future = self.robot_goal_client.call_async(request)
#         future.add_done_callback(self.handle_goal_response)

#     def handle_goal_response(self, future):
#         # Process the response
#         try:
#             response = future.result()
#             if response.success:
#                 self.get_logger().info(f"Goal successfully received.")
#             else:
#                 self.get_logger().error(f"Failed to set goal.")
#         except Exception as e:
#             self.get_logger().error(f"Service call failed: {e}")

#     def publish_final_result(self):

#         optimal_info = f"Optimal Bot: {self.min_bot}, Coordinate: ({self.min_x}, {self.min_y})"
#         self.publisher.publish(String(data=optimal_info))
#         self.get_logger().info(f"Final Published: {optimal_info}")


# def main(args=None):
#     rclpy.init(args=args)
#     num_robots = 4
#     minimal_service = MinimalService(num_robots)
#     rclpy.spin(minimal_service)
#     rclpy.shutdown()


# if __name__ == '__main__':
#     main()



# # from arm_interface_pkg.srv import Navigator
# # import rclpy
# # from rclpy.node import Node
# # from std_msgs.msg import String


# # class MinimalClient(Node):
# #     def __init__(self, num_robots):
# #         super().__init__('minimal_client')

# #         # Create service client
# #         self.client = self.create_client(Navigator, 'navigate_robot')

# #         # Wait for the service to be available
# #         while not self.client.wait_for_service(timeout_sec=1.0):
# #             self.get_logger().info('Service not available, waiting again...')

# #         # Initialize variables
# #         self.num_robots = num_robots

# #     def send_request(self, robot_namespace, x_goal, y_goal, yaw_goal):
# #         # Create a request message
# #         request = Navigator.Request()
# #         request.robot_namespace = robot_namespace
# #         request.x_goal = x_goal
# #         request.y_goal = y_goal
# #         request.yaw_goal = yaw_goal

# #         # Send the request and process the response
# #         self.get_logger().info(f"Requesting optimal path for robot {robot_namespace} with goal ({x_goal}, {y_goal}, {yaw_goal})")
        
# #         future = self.client.call_async(request)
# #         future.add_done_callback(self.handle_response)

# #     def handle_response(self, future):
# #         # Process the response
# #         try:
# #             response = future.result()
# #             if response.success:
# #                 self.get_logger().info(f"Optimal path found for robot {response.robot_namespace}. Success: {response.success}")
# #                 success = True
# #             else:
# #                 self.get_logger().error(f"Request failed for robot {response.robot_namespace}. Success: {response.success}")
# #                 success = False
# #         except Exception as e:
# #             self.get_logger().error(f"Service call failed: {e}")
# #             success = False

# #         # Returning the success as a boolean result
# #         return success


# # def main(args=None):
# #     rclpy.init(args=args)

# #     # Client setup
# #     num_robots = 4
# #     minimal_client = MinimalClient(num_robots)

# #     # Request bot namespace and coordinates
# #     robot_namespace = "tb1"  # Example bot name
# #     x_goal, y_goal, yaw_goal = 1.0, 2.0, 0.5  # Example goal coordinates and yaw for the bot

# #     # Send request and receive response
# #     success = minimal_client.send_request(robot_namespace, x_goal, y_goal, yaw_goal)

# #     # Log the success result
# #     if success:
# #         minimal_client.get_logger().info("Request was successful.")
# #     else:
# #         minimal_client.get_logger().error("Request failed.")

# #     rclpy.spin(minimal_client)
# #     rclpy.shutdown()


# # if __name__ == '__main__':
# #     main()


# # from arm_interface_pkg.srv import TurtleOptPath
# # import rclpy
# # from rclpy.node import Node
# # from geometry_msgs.msg import PoseStamped
# # from tf_transformations import quaternion_from_euler
# # from std_msgs.msg import String


# # class MinimalClient(Node):
# #     def __init__(self, num_robots):
# #         super().__init__('minimal_client')

# #         # Create service client
# #         self.client = self.create_client(TurtleOptPath, 'navigate_robot')

# #         # Wait for the service to be available
# #         while not self.client.wait_for_service(timeout_sec=1.0):
# #             self.get_logger().info('Service not available, waiting again...')

# #         # Initialize variables
# #         self.num_robots = num_robots

# #     def create_pose(self, x, y, z, ox, oy, oz):
# #         oxx, oyy, ozz, oww = quaternion_from_euler(ox, oy, oz)
# #         pose = PoseStamped()
# #         pose.header.frame_id = 'map'
# #         pose.pose.position.x = float(x)
# #         pose.pose.position.y = float(y)
# #         pose.pose.position.z = float(z)
# #         pose.pose.orientation.x = oxx
# #         pose.pose.orientation.y = oyy
# #         pose.pose.orientation.z = ozz
# #         pose.pose.orientation.w = oww
# #         return pose

# #     def send_request(self, bot_name, coordinates):
# #         # Create a request message
# #         request = TurtleOptPath.Request()
# #         request.label = bot_name

# #         # Call the service and send coordinates for the request
# #         self.get_logger().info(f"Requesting optimal path for {bot_name} with coordinates {coordinates}")
        
# #         # Here, we assume that coordinates is a list of (x, y) pairs
# #         for coord in coordinates:
# #             goal_pose = self.create_pose(coord[0], coord[1], 0, 0, 0, 0)
# #             request.coordinates.append(goal_pose)

# #         # Send the request and process the response
# #         future = self.client.call_async(request)
# #         future.add_done_callback(self.handle_response)

# #     def handle_response(self, future):
# #         # Process the response
# #         try:
# #             response = future.result()
# #             if response.bot != 'Failure':
# #                 self.get_logger().info(f"Optimal bot is {response.bot} at coordinates ({response.x}, {response.y})")
# #                 success = True
# #             else:
# #                 self.get_logger().error('Request failed: No such item in the environment.')
# #                 success = False
# #         except Exception as e:
# #             self.get_logger().error(f"Service call failed: {e}")
# #             success = False

# #         # Returning the success as a boolean result
# #         return success


# # def main(args=None):
# #     rclpy.init(args=args)

# #     # Client setup
# #     num_robots = 4
# #     minimal_client = MinimalClient(num_robots)

# #     # Request bot name and coordinates
# #     bot_name = "tb1"  # Example bot name
# #     coordinates = [(1.0, 2.0), (3.0, 4.0)]  # Example coordinates for the bot

# #     # Send request and receive response
# #     success = minimal_client.send_request(bot_name, coordinates)

# #     # Log the success result
# #     if success:
# #         minimal_client.get_logger().info("Request was successful.")
# #     else:
# #         minimal_client.get_logger().error("Request failed.")

# #     rclpy.spin(minimal_client)
# #     rclpy.shutdown()


# # if __name__ == '__main__':
# #     main()
