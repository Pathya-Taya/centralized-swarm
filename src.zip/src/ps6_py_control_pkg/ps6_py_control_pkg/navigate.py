#!/usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from math import sin, cos
from arm_interface_pkg.srv import Navigator

class NavigationServer(Node):
    def __init__(self):
        super().__init__('navigation_server')
        self.get_logger().info("Navigation server started.")
        
        # Create a service to handle navigation requests
        self.srv = self.create_service(
            Navigator,  # Custom service type
            'navigate_robot',  # Service name
            self.handle_navigation_request
        )

    def handle_navigation_request(self, request, response):
        # Extract details from the request
        robot_namespace = request.robot_namespace
        x_goal = request.x_goal
        y_goal = request.y_goal
        yaw_goal = request.yaw_goal

        # Log the incoming request
        self.get_logger().info(f"Received navigation request for {robot_namespace}: x={x_goal}, y={y_goal}, yaw={yaw_goal}")

        # Navigate the robot
        try:
            navigation_client = NavigationClient(robot_namespace)
            navigation_client.send_goal(x_goal, y_goal, yaw_goal)
            rclpy.spin_once(navigation_client, timeout_sec=0.1)
            response.success = True
        except Exception as e:
            self.get_logger().error(f"Navigation failed: {e}")
            response.success = False
        
        return response


class NavigationClient(Node):
    def __init__(self, robot_namespace):
        super().__init__('navigation_client')
        self.robot_namespace = robot_namespace
        self.action_client = ActionClient(self, NavigateToPose, f'/{robot_namespace}/navigate_to_pose')

    def send_goal(self, x, y, yaw):
        # Create a goal message
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = self.create_pose(x, y, yaw)

        # Wait for the server to become available
        self.action_client.wait_for_server()

        # Send the goal
        self.get_logger().info(f"Sending goal to {self.robot_namespace}: x={x}, y={y}, yaw={yaw}")
        self._send_goal_future = self.action_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info("Goal rejected :(")
            return

        self.get_logger().info("Goal accepted :)")
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        if result.result == NavigateToPose.Result.SUCCEEDED:
            self.get_logger().info("Goal reached successfully!")
        else:
            self.get_logger().info("Goal failed :(")

    def create_pose(self, x, y, yaw):
        # Create a PoseStamped message
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.orientation.z = sin(yaw / 2.0)
        pose.pose.orientation.w = cos(yaw / 2.0)
        return pose


def main(args=None):
    rclpy.init(args=args)

    navigation_server = NavigationServer()

    # Spin the server to keep it active
    rclpy.spin(navigation_server)

    # Shutdown when done
    rclpy.shutdown()


if __name__ == '__main__':
    main()



