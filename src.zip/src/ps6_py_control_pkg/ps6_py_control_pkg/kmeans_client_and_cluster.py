import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from arm_interface_pkg.msg import CoordLabelArray 
from arm_interface_pkg.srv import Kmeans
import json


#######################################################################################################3

import subprocess



###########################################################################################################

class LabelCoordinateSubscriber(Node):
    def __init__(self):
        super().__init__('label_coordinate_subscriber')
        
        self.label_dict = {}
        self.final_dict = self.label_dict

        self.returnint_pose = self.create_subscription(Bool, "/exploration_comp", self.exploration_comp_callback, 10)
        # self.pub_cluster = self.create_publisher()

        
        self.subscription = self.create_subscription(
            CoordLabelArray,
            '/obj/coord/label',
            self.listener_callback,
            10
        )
        self.subscription  
        self.get_logger().info('Subscribed to /obj/coord/label')

    def exploration_comp_callback(self, msg:Bool):
        self.stop_explor = msg.data
        if self.stop_explor == True:
            self.final_dict = self.label_dict

            for x in self.final_dict:
                #########################################################################################################

                self.command = "ros2 run nav2_map_server map_saver_cli -f ~/hullahua_map"

                # Run the command
                self.result = subprocess.run(self.command, shell=True, capture_output=True, text=True)

                if self.result.stderr:
                    print("Error:")
                    print(self.result.stderr)

                #########################################################################################################

                self.cli = self.create_client(Kmeans, 'process_kmeans')

                while not self.cli.wait_for_service(timeout_sec=1.0):
                    self.get_logger().info('service not available, waiting again...')

                self.req = Kmeans.Request()

                self.req.x_coordinates = self.final_dict[x][0]
                self.req.y_coordinates = self.final_dict[x][1]

                
                self.future = self.cli.call_async(self.req)
                rclpy.spin_until_future_complete(self, self.future)
                response = self.future.result()
                self.final_dict[x] = list(zip(response.centroids_x, response.centroids_y))


            self.get_logger().info(f"final dictionary is hulla hua !!! {self.final_dict}")


            json_objjj = json.dumps(self.final_dict, indent = 4)

            with open("label_with_cord.py", mode='w') as file:
                file.write(f"variable = {json_objjj}")

        
                            
        


    def listener_callback(self, msg):
        for entry in msg.entries:
            # Skip entries with invalid coordinates (e.g., [inf, inf])
            if float('inf')  in [entry.x, entry.y]:
                continue
            if float('-inf') in [entry.x , entry.y]:
                continue

            if entry.label in self.label_dict:
                self.label_dict[entry.label].append([entry.x, entry.y])
            else:
                self.label_dict[entry.label] = [[entry.x, entry.y]]
        
        # self.get_logger().info(f'Updated dictionary: {self.label_dict}')



def main(args=None):
    rclpy.init(args=args)
    label_coordinate_subscriber = LabelCoordinateSubscriber()
    rclpy.spin(label_coordinate_subscriber)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
