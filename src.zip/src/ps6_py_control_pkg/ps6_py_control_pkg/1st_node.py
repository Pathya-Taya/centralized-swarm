def main():
    print('Hi from ps6_py_control_pkg.')


if __name__ == '__main__':
    main()
