import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from tf_transformations import euler_from_quaternion

class CurrentPoseSubscriber(Node):
    def __init__(self):
        super().__init__('robot_current_pose_subscriber')
        self.robot_pose_subscriber = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self.listener_callback,
            10
        )
        self.get_logger().info("Subscribed to /amcl_pose")

    def listener_callback(self, msg):
        # Extract position
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        z = msg.pose.pose.position.z

        # Extract orientation and convert to Euler angles
        orientation = msg.pose.pose.orientation
        o_r, o_p, o_y = euler_from_quaternion([
            orientation.x,
            orientation.y,
            orientation.z,
            orientation.w
        ])

        self.get_logger().info(f"Position -> x: {x}, y: {y}, z: {z}")
        self.get_logger().info(f"Orientation -> roll: {o_r}, pitch: {o_p}, yaw: {o_y}")

def main(args=None):
    rclpy.init(args=args)
    node = CurrentPoseSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
