import rclpy
from rclpy.node import Node
from arm_interface_pkg.srv import Kmeans
import numpy as np
from sklearn.cluster import KMeans as SKLearnKMeans
import matplotlib.pyplot as plt


#command :: ros2 service call /process_kmeans arm_interface_pkg/srv/Kmeans "{x_coordinates: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0,7.0,7.0], y_coordinates: [1.1, 2.2, 3.1, 4.3, 5.1, 6.2, 7.3,7.0,7.0]}"


# Dynamic KMeans function
# def dynamic_kmeans(data, threshold=0.1, max_clusters=10):
#     inertia_values = []
#     cluster_range = range(1, max_clusters + 1)

#     for k in cluster_range:
#         kmeans = SKLearnKMeans(n_clusters=k, random_state=42)
#         kmeans.fit(data)
#         inertia_values.append(kmeans.inertia_)

#     optimal_num_clusters = 1
#     for i in range(1, len(inertia_values)):
#         relative_improvement = (inertia_values[i - 1] - inertia_values[i]) / inertia_values[i - 1]
#         if relative_improvement < threshold:
#             break
#         optimal_num_clusters = i + 1

#     kmeans = SKLearnKMeans(n_clusters=optimal_num_clusters, random_state=42)
#     kmeans.fit(data)

#     centroids = kmeans.cluster_centers_
#     labels = kmeans.labels_

#     return optimal_num_clusters, centroids, labels

def dynamic_kmeans(data, threshold=0.6, max_clusters=10):
    # Ensure the number of clusters doesn't exceed the number of samples
    n_samples = len(data)
    max_clusters = min(max_clusters, n_samples)  # Limit the max clusters

    inertia_values = []
    cluster_range = range(1, max_clusters + 1)

    for k in cluster_range:
        kmeans = SKLearnKMeans(n_clusters=k, random_state=42)
        kmeans.fit(data)
        inertia_values.append(kmeans.inertia_)

    optimal_num_clusters = 1
    for i in range(1, len(inertia_values)):
        # Avoid division by zero
        if inertia_values[i - 1] == 0:
            relative_improvement = 0
        else:
            relative_improvement = (inertia_values[i - 1] - inertia_values[i]) / inertia_values[i - 1]

        # If the relative improvement is smaller than the threshold, stop
        if relative_improvement < threshold:
            break
        optimal_num_clusters = i + 1

    # Fit the KMeans with the optimal number of clusters
    kmeans = SKLearnKMeans(n_clusters=optimal_num_clusters, random_state=42)
    kmeans.fit(data)

    centroids = kmeans.cluster_centers_
    labels = kmeans.labels_

    return optimal_num_clusters, centroids, labels



class KMeansServer(Node):
    def __init__(self):
        super().__init__('kmeans_server')
        self.srv = self.create_service(Kmeans, 'process_kmeans', self.process_kmeans_callback)
        self.get_logger().info("Server is running")

    def process_kmeans_callback(self, request, response):
        # Combine x and y coordinates into 2D array
        data = np.column_stack((request.x_coordinates, request.y_coordinates))
        
        # Apply KMeans
        optimal_num_clusters, centroids, labels = dynamic_kmeans(data)

        # Prepare response
        response.optimal_num_clusters = optimal_num_clusters
        response.centroids_x = centroids[:, 0].tolist()
        response.centroids_y = centroids[:, 1].tolist()
        response.labels = labels.tolist()

        self.get_logger().info(f"Processed KMeans: {optimal_num_clusters} clusters")

        return response

def main(args=None):
    rclpy.init(args=args)
    kmeans_server = KMeansServer()
    rclpy.spin(kmeans_server)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
