import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from nav2_msgs.action import ComputePathToPose
from geometry_msgs.msg import PoseStamped
from math import sqrt
from tf_transformations import quaternion_from_euler


class PathLengthActionClient(Node):
    def __init__(self):
        super().__init__('path_length_action_client')

        # Create an Action Client for ComputePathToPose
        self.action_client_1 = ActionClient(self, ComputePathToPose, 'tb1/compute_path_to_pose')
        self.action_client_2 = ActionClient(self, ComputePathToPose, 'tb2/compute_path_to_pose')
        self.action_client_3 = ActionClient(self, ComputePathToPose, 'tb3/compute_path_to_pose')
        self.action_client_4 = ActionClient(self, ComputePathToPose, 'tb4/compute_path_to_pose')

        # Define multiple goal poses
        self.goal_poses = [
            self.create_pose(1.0, 1.0, 0.0, 0.0, 0.0, 1.0),
            self.create_pose(2.0, 2.0, 0.0, 0.0, 0.0, 1.0),
        ]

        # x, y , z and roll , pitch , yaw 

        self.current_goal_index = 0
        self.send_goal()


    def create_pose(self, x, y, z, ox, oy, oz):
        oxx, oyy,ozz, oww = quaternion_from_euler(ox, oy,oz)
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = z
        pose.pose.orientation.x = oxx
        pose.pose.orientation.y = oyy
        pose.pose.orientation.z = ozz
        pose.pose.orientation.w = oww
        return pose

    def send_goal(self):
        # Define the goal request
        if self.current_goal_index < len(self.goal_poses):
            goal_msg = ComputePathToPose.Goal()
            goal_msg.goal = self.goal_poses[self.current_goal_index]
            goal_msg.planner_id = ''
            goal_msg.use_start = False

            self.get_logger().info(f'Sending goal {self.current_goal_index + 1}...')
            self.action_client.wait_for_server()

            self._send_goal_future = self.action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
            self._send_goal_future.add_done_callback(self.goal_response_callback)
        else:
            self.get_logger().info('All goals processed.')

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Goal was rejected by the server.')
            return

        self.get_logger().info('Goal accepted by the server.')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Result received.')

        # Check if the path is valid and calculate its length
        if result.path.poses:  # Ensure the path has poses
            path_length = self.calculate_path_length(result.path)
            self.get_logger().info(f'Path length to goal {self.current_goal_index + 1}: {path_length:.2f} meters')
        else:
            self.get_logger().error(f'Received an empty path for goal {self.current_goal_index + 1}.')

        # Move to the next goal
        self.current_goal_index += 1
        self.send_goal()

    def feedback_callback(self, feedback_msg):
        self.get_logger().info('Received feedback.')

    @staticmethod
    def calculate_path_length(path):
        length = 0.0
        for i in range(1, len(path.poses)):
            x1, y1 = path.poses[i - 1].pose.position.x, path.poses[i - 1].pose.position.y
            x2, y2 = path.poses[i].pose.position.x, path.poses[i].pose.position.y
            length += sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        return length


def main(args=None):
    rclpy.init(args=args)
    node = PathLengthActionClient()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
