import rclpy
from rclpy.node import Node
from arm_interface_pkg.srv import SelectPoints
import numpy as np
import cv2  # OpenCV for handling image loading
from scipy.ndimage import convolve

class SelectPointsServer(Node):

    def __init__(self):
        super().__init__('select_points_server')
        self.srv = self.create_service(SelectPoints, 'select_points', self.select_points_callback)
        self.get_logger().info("Server is running")

    def apply_weighted_filter(self, image):
        size = 5  # Reduced filter size
        sigma = 2.0
        kernel = np.fromfunction(
            lambda x, y: np.exp(-((x - (size - 1) / 2) ** 2 + (y - (size - 1) / 2) ** 2) / (2 * sigma ** 2)),
            (size, size),
        )
        kernel /= np.sum(kernel)
        filtered_image = convolve(image, kernel, mode='reflect')
        return filtered_image

    def subtract_gaussian(self, image, center, sigma, exclusion_radius):
        y, x = center
        yy, xx = np.ogrid[:image.shape[0], :image.shape[1]]
        gaussian = np.exp(-((yy - y) ** 2 + (xx - x) ** 2) )
        gaussian *= image[y, x] / gaussian.max()
        mask = (yy - y) ** 2 + (xx - x) ** 2 <= exclusion_radius ** 2
        image[mask] = np.maximum(image[mask] - gaussian[mask], 1e-18)  # Avoid values going below zero
        return image

    def select_points_uniformly(self, image, num_points, exclusion_radius):
        image = image.astype(np.float32)
        image = self.apply_weighted_filter(image)  # Apply weighted filter
        image[image > 206] = 255
        image[image <= 206] = 0
        white_mask = image == 255  # Mask of white pixels

        selected_points = []
        height, width = image.shape
        wall_mask = np.zeros_like(image, dtype=bool)
        wall_mask[image == 0] = True  # Wall mask where image is black

        def distance_to_wall(y, x):
            """Helper function to calculate the minimum distance to the nearest wall."""
            return np.min(np.sqrt((y - np.where(wall_mask)[0]) ** 2 + (x - np.where(wall_mask)[1]) ** 2))

        for _ in range(num_points):
            valid_coords = np.column_stack(np.where(white_mask))  # Get valid coordinates of white pixels

            selected_point = None
            for _ in range(len(valid_coords)):
                # Select a random point weighted by image intensity
                random_point = valid_coords[np.random.choice(valid_coords.shape[0],
                                                            p=image[valid_coords[:, 0], valid_coords[:, 1]]**2 /
                                                            np.sum(image[valid_coords[:, 0], valid_coords[:, 1]]**2))]
                if all(np.linalg.norm(np.array(random_point) - np.array(pt)) >= exclusion_radius for pt in selected_points):
                    if distance_to_wall(random_point[0], random_point[1]) > exclusion_radius:
                        selected_point = random_point
                        break

            if selected_point is None:
                for _ in range(len(valid_coords)):
                    random_point = valid_coords[np.random.choice(valid_coords.shape[0])]
                    if all(np.linalg.norm(np.array(random_point) - np.array(pt)) >= exclusion_radius for pt in selected_points):
                        selected_point = random_point
                        break
            selected_points.append(tuple(selected_point))
            y, x = selected_point
            image = self.subtract_gaussian(image, (y, x), 2.0, exclusion_radius)  # Subtract Gaussian to avoid overlap

        return selected_points

    def select_points_callback(self, request, response):
        # Load image using OpenCV
        image_path = request.image_path
        im = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

        if im is None:
            self.get_logger().error(f"Failed to load image from {image_path}")
            return response

        # Call select_points_uniformly function
        selected_points = self.select_points_uniformly(im, request.num_points, request.exclusion_radius)

        # Separate x and y coordinates and ensure they're integers
        x_coords = [int(point[1]) for point in selected_points]  # x is column index
        y_coords = [int(point[0]) for point in selected_points]  # y is row index

        # Assign the coordinates to the response message
        response.x_coordinates = x_coords
        response.y_coordinates = y_coords
        return response

def main(args=None):
    rclpy.init(args=args)
    select_points_server = SelectPointsServer()
    rclpy.spin(select_points_server)
    select_points_server.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()



# import rclpy
# from rclpy.node import Node
# from custom_interfaces.srv import SelectPoints
# import numpy as np
# import cv2  # OpenCV for handling image loading
# from scipy.ndimage import convolve

# class SelectPointsServer(Node):

#     def __init__(self):
#         super().__init__('select_points_server')
#         self.srv = self.create_service(SelectPoints, 'select_points', self.select_points_callback)
#         self.get_logger().info("Server is running")

#     def apply_weighted_filter(self, image):
#         size = 100
#         sigma = 2.0
#         kernel = np.fromfunction(
#             lambda x, y: np.exp(-((x - (size - 1) / 2) ** 2 + (y - (size - 1) / 2) ** 2) / (2 * sigma ** 2)),
#             (size, size),
#         )
#         kernel /= np.sum(kernel)
#         filtered_image = convolve(image, kernel, mode='reflect')
#         return filtered_image

#     def subtract_gaussian(self, image, center, sigma, exclusion_radius):
#         y, x = center
#         yy, xx = np.ogrid[:image.shape[0], :image.shape[1]]
#         gaussian = np.exp(-((yy - y) ** 2 + (xx - x) ** 2) / (2 * sigma ** 2))
#         gaussian *= image[y, x] / gaussian.max()
#         mask = (yy - y) ** 2 + (xx - x) ** 2 <= exclusion_radius ** 2
#         image[mask] = np.maximum(image[mask] - gaussian[mask], 0.0)
#         return image

#     def select_points_uniformly(self, image, num_points, exclusion_radius):
#         image = image.astype(np.float32)
#         image[image > 206] = 255
#         image[image <= 206] = 0
#         white_mask = image == 255

#         selected_points = []
#         height, width = image.shape
#         wall_mask = np.zeros_like(image, dtype=bool)
#         wall_mask[image == 0] = True

#         def distance_to_wall(y, x):
#             """Helper function to calculate the minimum distance to the nearest wall."""
#             return np.min(np.sqrt((y - np.where(wall_mask)[0]) ** 2 + (x - np.where(wall_mask)[1]) ** 2))

#         for _ in range(num_points):
#             valid_coords = np.column_stack(np.where(white_mask))

#             selected_point = None
#             for _ in range(len(valid_coords)):
#                 random_point = valid_coords[np.random.choice(valid_coords.shape[0])]
#                 if all(np.linalg.norm(np.array(random_point) - np.array(pt)) >= exclusion_radius for pt in selected_points):
#                     if distance_to_wall(random_point[0], random_point[1]) > exclusion_radius:
#                         selected_point = random_point
#                         break

#             if selected_point is None:
#                 for _ in range(len(valid_coords)):
#                     random_point = valid_coords[np.random.choice(valid_coords.shape[0])]
#                     if all(np.linalg.norm(np.array(random_point) - np.array(pt)) >= exclusion_radius for pt in selected_points):
#                         selected_point = random_point
#                         break
#             selected_points.append(tuple(selected_point))
#             y, x = selected_point
#             image = self.subtract_gaussian(image, (y, x), 5, exclusion_radius)

#         return selected_points
    
#     def select_points_callback(self, request, response):
#     # Load image using OpenCV
#         image_path = request.image_path
#         im = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

#         if im is None:
#             self.get_logger().error(f"Failed to load image from {image_path}")
#             return response

#     # Call select_points_uniformly function
#         selected_points = self.select_points_uniformly(im, request.num_points, request.exclusion_radius)

#     # Separate x and y coordinates and ensure they're integers
#         x_coords = [int(point[1]) for point in selected_points]  # x is column index
#         y_coords = [int(point[0]) for point in selected_points]  # y is row index

#     # Assign the coordinates to the response message
#         response.x_coordinates = x_coords
#         response.y_coordinates = y_coords
#         return response


#     # def select_points_callback(self, request, response):
#     #     # Load image using OpenCV
#     #     image_path = request.image_path
#     #     im = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

#     #     if im is None:
#     #         self.get_logger().error(f"Failed to load image from {image_path}")
#     #         return response

#     #     # Call select_points_uniformly function
#     #     selected_points = self.select_points_uniformly(im, request.num_points, request.exclusion_radius)

#     #     # Separate x and y coordinates
#     #     x_coords = [point[1] for point in selected_points]  # x is column index
#     #     y_coords = [point[0] for point in selected_points]  # y is row index

#     #     response.x_coordinates = x_coords
#     #     response.y_coordinates = y_coords
#     #     return response


# def main(args=None):
#     rclpy.init(args=args)
#     select_points_server = SelectPointsServer()
#     rclpy.spin(select_points_server)
#     select_points_server.destroy_node()
#     rclpy.shutdown()


# if __name__ == '__main__':
#     main()
