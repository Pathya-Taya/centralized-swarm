import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ps6_py_control_pkg.YOLOv8 import Model
from arm_interface_pkg.msg import CoordLabel, CoordLabelArray


class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('image_subscriber')
        

        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            1
        )

        self.pub = self.create_publisher(CoordLabelArray, "cam_topic", 10)
        self.bridge = CvBridge()

    

    def listener_callback(self, data):
        # self.get_logger().info('Received image frame')

        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'Error converting image: {e}')
            return
        
        model = Model()
        lst = model.predict(cv_image)

        msg = CoordLabelArray()


        # Convert data to CoordLabel format
        msg.entries = [
            CoordLabel(x=(entry[0]/980)*28.5, y=(entry[1]/540)*28.5, label=entry[2])
            for entry in lst
        ]

        self.pub.publish(msg)
        self.get_logger().info(f'Published: {msg.entries}')

            
        

        

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)

    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
