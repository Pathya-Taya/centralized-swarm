import rclpy
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
import math

class ExplorationNode(Node):
    def __init__(self):
        super().__init__('exploration_node')

        # Create an action client to send navigation goals
        self._nav_client = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        # Subscribe to LaserScan data
        self.laserscan_subscriber = self.create_subscription(
            LaserScan,
            '/scan',
            self.laserscan_callback,
            10
        )

        self.get_logger().info("Exploration Node Initialized.")

        # Variables to store laser scan data
        self.laser_ranges = []

        # Define a flag to start exploring
        self.exploring = False

    def laserscan_callback(self, msg):
        # Store laser scan data for later use
        self.laser_ranges = msg.ranges

        # If we are in the exploration mode, proceed with goal generation
        if self.exploring:
            self.generate_exploration_goal()

    def generate_exploration_goal(self):
        """
        Generate an exploration goal based on the current laser scan data.
        Here we choose the frontier points (the closest uncharted areas).
        """
        # Dummy implementation of goal generation. 
        # This would be a more advanced approach in a real implementation.
        goal = PoseStamped()
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.header.frame_id = "map"

        # For simplicity, setting a fixed exploration point
        goal.pose.position.x = 5.0
        goal.pose.position.y = 5.0
        goal.pose.orientation.w = 1.0  # No rotation (facing along x-axis)

        self.get_logger().info(f"Generated goal at: {goal.pose.position.x}, {goal.pose.position.y}")
        
        self.send_goal_to_navigation_stack(goal)

    def send_goal_to_navigation_stack(self, goal):
        """
        Send the generated goal to the Navigation2 stack to navigate to it.
        """
        if self._nav_client.wait_for_server(timeout_sec=1.0):
            self.get_logger().info("Sending exploration goal to Navigation2.")
            goal_msg = NavigateToPose.Goal()
            goal_msg.pose = goal.pose

            self._nav_client.send_goal_async(goal_msg)

            self.get_logger().info("Goal sent. Waiting for result.")
        else:
            self.get_logger().warn("Navigation2 server not available!")

    def start_exploration(self):
        """
        Start the exploration process. This involves generating goals
        and navigating to unexplored areas based on laser scan data.
        """
        self.exploring = True
        self.get_logger().info("Starting exploration...")

def main(args=None):
    rclpy.init(args=args)
    node = ExplorationNode()

    node.start_exploration()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Exploration interrupted.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
