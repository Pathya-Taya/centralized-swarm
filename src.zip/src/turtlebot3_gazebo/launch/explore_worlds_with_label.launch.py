import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Paths to launch files
    turtlebot3_gazebo_dir = get_package_share_directory('turtlebot3_gazebo')
    # explore_lite_dir = get_package_share_directory('explore_lite')



    # Declare the use_sim_time argument
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # Include TurtleBot3 world launch
    turtlebot3_world_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(turtlebot3_gazebo_dir, 'launch', 'turtlebot3_ps6_world.launch.py')
        )
    )

    # Include Nav2 bringup launch
    nav2_bringup_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join("/opt/ros/humble/share/nav2_bringup/launch", 'navigation_launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items()
    )

    # Include SLAM toolbox launch
    # slam_toolbox_launch = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         os.path.join(slam_toolbox_dir, 'launch', 'online_async_launch.py')
    #     ),
    #     launch_arguments={'use_sim_time': use_sim_time}.items()
    # )

    # RViz2 command
    rviz2_command = ExecuteProcess(
        cmd=[
            'ros2',
            'run',
            'rviz2',
            'rviz2',
            '-d',
            os.path.join("/opt/ros/humble/share/nav2_bringup", 'rviz', 'nav2_default_view.rviz')
        ],
        output='screen'
    )

    # Include explore_lite launch
    # explore_lite_launch = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         os.path.join(explore_lite_dir, 'launch', 'explore.launch.py')
    #     )
    # )

    # Create launch description
    ld = LaunchDescription()

    # Add actions to launch description
    ld.add_action(turtlebot3_world_launch)
    ld.add_action(nav2_bringup_launch)
    # ld.add_action(slam_toolbox_launch)
    ld.add_action(rviz2_command)
    # ld.add_action(explore_lite_launch)

    return ld
